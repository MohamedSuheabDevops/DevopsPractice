# Screenshots

Save each screenshot here with the file name used in [RUN-IT.md](../../RUN-IT.md). Take the ones for the steps you actually did.

| File | Step | Shows |
|---|---|---|
| 01-image-size.png | 3 | Single-stage vs multi-stage image size |
| 02-compose-healthy.png | 4 | `docker compose ps`, everything healthy |
| 03-load-balancing.png | 5 | Different container ids in the curl loop |
| 04-k8s-pods.png | 8 | `helm list` and the running pods |
| 05-data-survives.png | 9 | Database rows still there after the pod was deleted |
| 06-self-healing.png | 10 | A deleted pod replaced |
| 07-bad-release.png | 11 | A failing new pod while old pods keep serving |
| 08-argocd-green.png | 14 | ArgoCD, all applications Synced and Healthy |
| 09-actions-release.png | 15 | Green release run (5 builds) |
| 10-bot-commit.png | 15 | The bot's `ci: deploy ...` commit |
| 11-git-revert-rollback.png | 17 | The revert commit and the app healthy again |
| 12-terraform-plan.png | 18 | `terraform plan` |
| 13-eks-nodes.png | 20 | `kubectl get nodes` on EKS (optional) |
| 14-alb-curl.png | 21 | Services answering through the ALB (optional) |
| 15-jaeger.png | 23 | Traces in the local lab (optional) |
